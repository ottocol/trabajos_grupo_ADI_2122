"use strict";(self["webpackChunkadi_ejemplo"]=self["webpackChunkadi_ejemplo"]||[]).push([[78],{78:function(e,t,n){n.r(t),n.d(t,{startStatusTap:function(){return r}});var o=n(65),s=n(587);
/*!
 * (C) Ionic http://ionicframework.com - MIT License
 */
const r=()=>{const e=window;e.addEventListener("statusTap",(()=>{(0,o.wj)((()=>{const t=e.innerWidth,n=e.innerHeight,r=document.elementFromPoint(t/2,n/2);if(!r)return;const i=r.closest("ion-content");i&&new Promise((e=>(0,s.c)(i,e))).then((()=>{(0,o.Iu)((async()=>{i.style.setProperty("--overflow","hidden"),await i.scrollToTop(300),i.style.removeProperty("--overflow")}))}))}))}))}}}]);
//# sourceMappingURL=78.da7cd98b.js.map