Para ejecutar el código:

> npm i
> node index.js

O para ejecutar en modo desarrollo con nodemon:

> npm run devstart