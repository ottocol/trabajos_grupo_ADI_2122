# adiTeoria
Proyecto grupal adi teoría
